const $ = id => document.getElementById(id);
let state = {name:"Student", attempts:[], tasks:[], career:"", goal:""};
const questions = [
 {topic:"Python",q:"How comfortable are you with Python basics?",opts:["I can write basic programs","I know a few concepts","I am just starting"]},
 {topic:"Mathematics",q:"How confident are you solving basic mathematical problems?",opts:["Confident","Need some practice","Need to learn from basics"]},
 {topic:"SQL",q:"Can you write a simple SQL query to retrieve data?",opts:["Yes, comfortably","I know SELECT basics","Not yet"]},
 {topic:"Communication",q:"How comfortable are you explaining your ideas?",opts:["Comfortable","Sometimes nervous","I need more practice"]},
 {topic:"Problem Solving",q:"How do you approach a new coding problem?",opts:["Break it into steps","Try with some help","Not sure how to start"]}
];
const esc=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
async function api(url,options={}){const r=await fetch(url,{headers:{"Content-Type":"application/json"},...options});const d=await r.json();if(!r.ok)throw new Error(d.error||"Request failed");return d;}
function showPage(page){document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id===page));document.querySelectorAll(".nav-link").forEach(b=>b.classList.toggle("active",b.dataset.page===page));$("pageTitle").textContent=({dashboard:"Dashboard",assessment:"Skill Assessment",planner:"Study Planner",career:"Career Guidance"})[page];if(page==="planner")loadTasks();}
document.querySelectorAll("[data-page]").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.page)));
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.go)));
$("today").textContent=new Date().toLocaleDateString(undefined,{weekday:"short",month:"short",day:"numeric"});
$("questions").innerHTML=questions.map((q,i)=>`<div class="question"><b>${i+1}. ${q.q}</b><div class="options">${q.opts.map((o,j)=>`<label><input type="radio" name="q${i}" value="${3-j}" ${j===0?"checked":""}> ${o}</label>`).join("")}</div></div>`).join("");
async function refresh(){
 const d=await api("/api/dashboard");state=d;
 $("sideName").textContent=d.name||"Student";$("studentName").value=d.name==="Student"?"":d.name;
 $("welcomeText").textContent=`Welcome${d.name==="Student"?"":", "+d.name}. Your next learning step is ready.`;
 $("attempts").textContent=d.attempts.length;$("average").textContent=(d.average||0)+"%";
 $("completed").textContent=d.completed_tasks;$("progressLabel").textContent=d.progress+"%";$("progressBar").style.width=d.progress+"%";
 if(d.recommendation){$("recommendTitle").textContent=d.recommendation.title;$("recommendText").textContent=d.recommendation.message;$("planFocus").textContent=d.recommendation.title;$("planSub").textContent=d.recommendation.message;}
 $("history").innerHTML=d.attempts.length?d.attempts.slice(0,5).map(a=>`<div class="history-row"><span>${new Date(a.created_at).toLocaleString()}</span><b>${a.score}%</b></div>`).join(""):'<p class="muted">Complete an assessment to see your history here.</p>';
}
$("submitQuiz").addEventListener("click",async()=>{
 const name=$("studentName").value.trim();if(!name){$("quizResult").classList.remove("hidden");$("quizResult").textContent="Please enter your name before submitting.";return;}
 const answers=questions.map((q,i)=>{const v=document.querySelector(`input[name="q${i}"]:checked`);return v?Number(v.value):1;});
 try{const result=await api("/api/assessment",{method:"POST",body:JSON.stringify({name,goal:$("goal").value,answers})});
 $("quizResult").classList.remove("hidden");$("quizResult").innerHTML=`<b>Assessment complete, ${esc(name)}!</b><br>Your learning confidence score is <b>${result.score}%</b>.<br>${result.weak_topics.length?`Focus areas: <b>${result.weak_topics.map(esc).join(", ")}</b>.`:"Great start! Keep practicing to strengthen your skills."}<br>Your adaptive study plan has been saved to the database.`;
 await refresh();showPage("assessment");
 }catch(e){alert(e.message);}
});
async function loadTasks(){
 const d=await api("/api/tasks");state.tasks=d.tasks;
 $("taskList").innerHTML=d.tasks.map(t=>`<label class="task ${t.done?"done":""}"><input type="checkbox" data-task="${t.id}" ${t.done?"checked":""}><span>${esc(t.title)}</span><small>${esc(t.duration)}</small></label>`).join("");
 document.querySelectorAll("[data-task]").forEach(box=>box.addEventListener("change",async()=>{await api("/api/tasks/"+box.dataset.task,{method:"PATCH",body:JSON.stringify({done:box.checked})});await loadTasks();await refresh();}));
 $("taskCount").textContent=`${d.completed} / ${d.total} done`;
}
$("addTask").addEventListener("click",async()=>{const title=$("newTask").value.trim();if(!title)return;await api("/api/tasks",{method:"POST",body:JSON.stringify({title})});$("newTask").value="";await loadTasks();await refresh();});
$("newTask").addEventListener("keydown",e=>{if(e.key==="Enter")$("addTask").click();});
document.querySelectorAll(".choose-career").forEach(b=>b.addEventListener("click",async()=>{const d=await api("/api/career",{method:"POST",body:JSON.stringify({career:b.dataset.career})});$("careerMessage").classList.remove("hidden");$("careerMessage").textContent=d.message;}));
(async()=>{try{await refresh();await loadTasks();}catch(e){alert("Could not connect to the local server. Please run START_APP.bat.");}})();
